# jquery.instagramFeed [![Build Status](https://travis-ci.com/jsanahuja/jquery.instagramFeed.svg?branch=master)](https://travis-ci.com/jsanahuja/jquery.instagramFeed)
Instagram Feed without using the instagram API

[Full documentation and examples here](https://www.sowecms.com/demos/jquery.instagramFeed/index.html "documentation")


## Try [InstagramFeed](https://github.com/jsanahuja/InstagramFeed), the same without jQuery!
